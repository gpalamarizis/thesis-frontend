﻿import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Layout from '../../components/Layout';
import Tabs from '../../components/Tabs';
import Modal from '../../components/Modal';
import ConfirmDialog from '../../components/ConfirmDialog';
import QuickCreatePersonModal from '../../components/QuickCreatePersonModal';
import CalendarExportButton from '../../components/CalendarExportButton';
import { cases, actions, documents, courts, people, fysika, nomika, lists, templates, courtSubActions } from '../../api';
import { fmtDate, fmtDateTime, toDateInput, trunc } from '../../utils/format';
import { extractFileMetadata } from '../../utils/fileMetadata';
import { createEmptyDocx, createEmptyXlsx, blobToFile } from '../../utils/emptyOfficeDoc';
import { eventFromCourtAction, eventFromTaskAction, eventFromCourtSubAction } from '../../utils/calendar';
import FinanceTab from './FinanceTab';
import TaskActionsTab from './TaskActionsTab';
import RelatedPersonsTab from './RelatedPersonsTab';
import RelatedCasesPanel from './RelatedCasesPanel';
import CaseInvoicesTab from './CaseInvoicesTab';

function CaseEdit({ user, onLogout, onOpenCaseSearch }) {
  const { id } = useParams();
  const navigate = useNavigate();

  const [caseData, setCaseData] = useState(null);
  const [courtActions, setCourtActions] = useState([]);
  const [taskActions, setTaskActions] = useState([]);
  const [docs, setDocs] = useState([]);
  const [courtsList, setCourtsList] = useState([]);
  const [initialLoading, setInitialLoading] = useState(true);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);
  const [okMsg, setOkMsg] = useState('');

  const loadAll = (isInitial = false) => {
    if (isInitial) setInitialLoading(true);
    Promise.allSettled([
      cases.get(id),
      actions.court.listByCase(id),
      actions.task.listByCase(id),
      documents.listByCase(id),
      courts.list(),
    ]).then(([cRes, chRes, ctRes, dRes, ctsRes]) => {
      if (cRes.status === 'fulfilled') {
        setCaseData(cRes.value?.data || cRes.value);
        setError('');
      } else if (isInitial) {
        setError(cRes.reason?.message || 'Σφάλμα φόρτωσης');
      }
      const unwrap = v => Array.isArray(v) ? v : (v?.data || []);
      if (chRes.status === 'fulfilled')  setCourtActions(unwrap(chRes.value));
      if (ctRes.status === 'fulfilled')  setTaskActions(unwrap(ctRes.value));
      if (dRes.status === 'fulfilled')   setDocs(unwrap(dRes.value));
      if (ctsRes.status === 'fulfilled') setCourtsList(unwrap(ctsRes.value));
    }).finally(() => {
      if (isInitial) setInitialLoading(false);
    });
  };

  useEffect(() => { loadAll(true); /* eslint-disable-next-line */ }, [id]);

  const saveCase = async (patch) => {
    setSaving(true);
    setError('');
    setOkMsg('');
    try {
      await cases.update(id, patch);
      setOkMsg('Οι αλλαγές αποθηκεύτηκαν.');
      setTimeout(() => setOkMsg(''), 3000);
      loadAll(false);
    } catch (e) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  };

  if (initialLoading) return <Layout user={user} onLogout={onLogout} onOpenCaseSearch={onOpenCaseSearch} title="Υπόθεση"><div className="empty-state">Φόρτωση...</div></Layout>;
  if (!caseData) return <Layout user={user} onLogout={onLogout} onOpenCaseSearch={onOpenCaseSearch} title="Υπόθεση"><div className="error">{error || 'Δεν βρέθηκε η υπόθεση.'}</div></Layout>;

  return (
    <Layout user={user} onLogout={onLogout} onOpenCaseSearch={onOpenCaseSearch} title={`Υπόθεση ${caseData.xeirokinito_id || ''}`}>
      {error && <div className="error">{error}</div>}
      {okMsg && <div className="success">{okMsg}</div>}

      <div className="section">
        <Tabs tabs={[
          { label: 'Υπόθεση',              content: <CaseTab caseData={caseData} onSave={saveCase} saving={saving} /> },
          { label: 'Δικαστικές ενέργειες', badge: courtActions.length, content: <CourtActionsTab caseId={id} rows={courtActions} courts={courtsList} onChange={() => loadAll(false)} /> },
          { label: 'Λοιπές ενέργειες',     badge: taskActions.length,  content: <TaskActionsTab caseId={id} rows={taskActions} onChange={() => loadAll(false)} /> },
          { label: 'Σχετικά πρόσωπα',      content: <RelatedPersonsTab caseId={id} /> },
          { label: 'Αρχεία',               badge: docs.length,         content: <DocsTab caseId={id} rows={docs} onChange={() => loadAll(false)} /> },
          { label: 'Οικονομικά',           content: <FinanceTab caseId={id} /> },
          { label: 'Τιμολόγια',            content: <CaseInvoicesTab caseId={id} /> },
        ]}/>
      </div>

      <div className="form-actions">
        <button type="button" className="btn btn-secondary" onClick={() => navigate('/cases')}>← Πίσω στη λίστα</button>
      </div>
    </Layout>
  );
}

// ---------- Tab 1: Case ----------
function CaseTab({ caseData, onSave, saving }) {
  const [perilipsi, setPerilipsi] = useState(caseData.perilipsi || '');
  const [dateEisagogis, setDateEisagogis] = useState(toDateInput(caseData.date_eisagogis));
  const [dateTelous, setDateTelous] = useState(toDateInput(caseData.date_telous));
  const [ekkremis, setEkkremis] = useState(caseData.ekkremis !== false);
  const [onomasiaFakelou, setOnomasiaFakelou] = useState(caseData.onomasia_fakelou || '');
  const [thesiArxeiothetisisId, setThesiArxeiothetisisId] = useState(caseData.thesi_arxeiothetisis_id || '');
  const [oldKod, setOldKod] = useState(caseData.old_kod || '');
  const [gak, setGak] = useState(caseData.gak || '');
  const [eak, setEak] = useState(caseData.eak || '');
  const [arithmosEisagogikou, setArithmosEisagogikou] = useState(caseData.arithmos_eisagogikou || '');
  const [onomasiaId, setOnomasiaId] = useState(caseData.onomasia_id || '');
  const [thesi, setThesi] = useState(caseData.thesi || '');
  const [fysikoProsopoId, setFysikoProsopoId] = useState(caseData.fysiko_prosopo_id || '');
  const [nomikoProsopoId, setNomikoProsopoId] = useState(caseData.nomiko_prosopo_id || '');
  const [archiveOptions, setArchiveOptions] = useState([]);
  const [onomasiaOptions, setOnomasiaOptions] = useState([]);
  const [thesiOptions, setThesiOptions] = useState([]);
  const [fysikaList, setFysikaList] = useState([]);
  const [nomikaList, setNomikaList] = useState([]);
  const [sameClientCases, setSameClientCases] = useState([]);
  const [showInactiveLawyers, setShowInactiveLawyers] = useState(false);

  // Merged from PeopleTab
  const initialXeiristes = Array.isArray(caseData.xeiristes)
    ? caseData.xeiristes.map(x => x.aa || x.id).filter(Boolean)
    : [];
  const [xeiristesIds, setXeiristesIds] = useState(initialXeiristes);
  const [diadikosId, setDiadikosId] = useState(caseData.diadikos_id || '');
  const [lawyers, setLawyers] = useState([]);
  const [opponents, setOpponents] = useState([]);
  const [loadErr, setLoadErr] = useState('');
  const [quickCreate, setQuickCreate] = useState(null);

  const reloadFysika = () => fysika.list()
    .then(d => setFysikaList(Array.isArray(d) ? d : (d?.data || [])))
    .catch(() => {});
  const reloadNomika = () => nomika.list()
    .then(d => setNomikaList(Array.isArray(d) ? d : (d?.data || [])))
    .catch(() => {});

  const reloadPeople = () => {
    Promise.allSettled([
      people.lawyers.list(),
      people.opponents.list(),
    ]).then(([lRes, oRes]) => {
      const unwrap = v => Array.isArray(v) ? v : (v?.data || []);
      if (lRes.status === 'fulfilled')  setLawyers(unwrap(lRes.value));
      if (oRes.status === 'fulfilled')  setOpponents(unwrap(oRes.value));
      const errs = [lRes, oRes].filter(r => r.status === 'rejected').map(r => r.reason?.message);
      if (errs.length) setLoadErr(errs.join('; '));
    });
  };

  useEffect(() => {
    lists.get('theseis_arxeiothetisis')
      .then(d => setArchiveOptions(Array.isArray(d) ? d : (d?.data || [])))
      .catch(() => {});
    lists.get('ypotheseis_onomasies')
      .then(d => setOnomasiaOptions(Array.isArray(d) ? d : (d?.data || [])))
      .catch(() => {});
    lists.get('thesi')
      .then(d => setThesiOptions(Array.isArray(d) ? d : (d?.data || [])))
      .catch(() => {});
    reloadFysika();
    reloadNomika();
    reloadPeople();
    if (caseData && (caseData.aa || caseData.id)) {
      cases.sameClient(caseData.aa || caseData.id)
        .then(d => setSameClientCases(Array.isArray(d) ? d : (d?.data || [])))
        .catch(() => setSameClientCases([]));
    }
  }, []);

  useEffect(() => {
    setPerilipsi(caseData.perilipsi || '');
    setDateEisagogis(toDateInput(caseData.date_eisagogis));
    setDateTelous(toDateInput(caseData.date_telous));
    setEkkremis(caseData.ekkremis !== false);
    setOnomasiaFakelou(caseData.onomasia_fakelou || '');
    setThesiArxeiothetisisId(caseData.thesi_arxeiothetisis_id || '');
    setOldKod(caseData.old_kod || '');
    setGak(caseData.gak || '');
    setEak(caseData.eak || '');
    setArithmosEisagogikou(caseData.arithmos_eisagogikou || '');
    setXeiristesIds(Array.isArray(caseData.xeiristes) ? caseData.xeiristes.map(x => x.aa || x.id).filter(Boolean) : []);
    setDiadikosId(caseData.diadikos_id || '');
    setOnomasiaId(caseData.onomasia_id || '');
    setThesi(caseData.thesi || '');
    setFysikoProsopoId(caseData.fysiko_prosopo_id || '');
    setNomikoProsopoId(caseData.nomiko_prosopo_id || '');
  }, [caseData.aa, caseData.perilipsi, caseData.date_eisagogis, caseData.date_telous, caseData.ekkremis, caseData.onomasia_fakelou, caseData.thesi_arxeiothetisis_id, caseData.old_kod, caseData.diadikos_id, caseData.xeiristes, caseData.onomasia_id, caseData.thesi, caseData.fysiko_prosopo_id, caseData.nomiko_prosopo_id]);

  const toggleXeiristis = (id) => {
    setXeiristesIds(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  const handleQuickCreated = (kind, rec) => {
    setQuickCreate(null);
    const newId = rec?.aa || rec?.id;
    if (kind === 'fysiko') {
      reloadFysika();
      if (newId) { setFysikoProsopoId(String(newId)); setNomikoProsopoId(''); }
    } else if (kind === 'nomiko') {
      reloadNomika();
      if (newId) { setNomikoProsopoId(String(newId)); setFysikoProsopoId(''); }
    } else if (kind === 'lawyer') {
      reloadPeople();
      if (newId) setXeiristesIds(prev => [...prev, newId]);
    } else if (kind === 'opponent') {
      reloadPeople();
      if (newId) setDiadikosId(newId);
    }
  };

  const clientLabel = caseData.fysiko_full_name
    || caseData.nomiko_eponymia
    || (caseData.fysiko_prosopo_id ? `Φυσικό πρόσωπο #${caseData.fysiko_prosopo_id}`
        : caseData.nomiko_prosopo_id ? `Νομικό πρόσωπο #${caseData.nomiko_prosopo_id}` : '—');

  const saveAll = () => onSave({
    perilipsi:               perilipsi || null,
    date_eisagogis:          dateEisagogis || null,
    date_telous:             dateTelous || null,
    onomasia_fakelou:        onomasiaFakelou || null,
    thesi_arxeiothetisis_id: thesiArxeiothetisisId ? Number(thesiArxeiothetisisId) : null,
    old_kod:                 oldKod || null,
    gak:                     gak || null,
    eak:                     eak || null,
    arithmos_eisagogikou:    arithmosEisagogikou || null,
    ekkremis:                ekkremis,
    diadikos_id:             diadikosId ? Number(diadikosId) : null,
    xeiristes_ids:           xeiristesIds.map(Number),
    onomasia_id:             onomasiaId ? Number(onomasiaId) : null,
    thesi:                   thesi ? Number(thesi) : null,
    fysiko_prosopo_id:       fysikoProsopoId ? Number(fysikoProsopoId) : null,
    nomiko_prosopo_id:       nomikoProsopoId ? Number(nomikoProsopoId) : null,
  });

  return (
    <div className="case-tab-layout" style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 20, alignItems: 'start' }}>
      <div className="case-tab-main">
        <div className="form-grid-2">
          <div className="form-group">
            <label>Αριθμός Πρωτοκόλλου</label>
            <input type="text" value={caseData.xeirokinito_id || ''} readOnly />
          </div>
          <div className="form-group">
            <label>Κατάσταση</label>
            <select value={ekkremis ? '1' : '0'} onChange={e => setEkkremis(e.target.value === '1')}>
              <option value="1">Εκκρεμής</option>
              <option value="0">Κλεισμένη</option>
            </select>
          </div>
        </div>
        <div className="form-grid-2">
          <div className="form-group">
            <label>Ημερομηνία εισαγωγής</label>
            <input type="date" value={dateEisagogis} onChange={e => setDateEisagogis(e.target.value)} />
          </div>
          <div className="form-group">
            <label>Ημερομηνία τέλους</label>
            <input type="date" value={dateTelous} onChange={e => setDateTelous(e.target.value)} />
          </div>
        </div>
        {/* ΑΦΑΙΡΕΘΗΚΕ: «Ονομασία φακέλου».
            Πεδίο του παλιού VB.NET που ΔΕΝ χρησιμοποιήθηκε ποτέ —
            0 από 4.540 υποθέσεις σε 24 χρόνια είχαν τιμή.
            Η κατάσταση διατηρείται και αποθηκεύεται κανονικά, ώστε
            τυχόν υπάρχουσες τιμές να μη χαθούν και να μπορεί να
            επανέλθει το πεδίο με μία γραμμή αν χρειαστεί. */}
        <div className="form-grid-2">
          <div className="form-group">
            <label>Αρχειοθετημένη σε</label>
            <select value={thesiArxeiothetisisId} onChange={e => setThesiArxeiothetisisId(e.target.value)}>
              <option value="">-- επιλογή --</option>
              {archiveOptions.map(o => <option key={o.aa || o.id} value={o.aa || o.id}>{o.name || '—'}</option>)}
            </select>
          </div>
        </div>
        <div className="form-grid-2">
          <div className="form-group">
            <label>Παλιός Κωδικός</label>
            <input type="text" value={oldKod} onChange={e => setOldKod(e.target.value)} />
          </div>
          <div />
        </div>
        <div className="form-grid-2">
          <div className="form-group">
            <label>Είδος υπόθεσης</label>
            <select value={onomasiaId} onChange={e => setOnomasiaId(e.target.value)}>
              <option value="">— κανένα —</option>
              {onomasiaOptions.map(o => <option key={o.aa || o.id} value={o.aa || o.id}>{o.name}</option>)}
            </select>
          </div>
          <div className="form-group">
            <label>Θέση στην υπόθεση</label>
            <select value={thesi} onChange={e => setThesi(e.target.value)}>
              <option value="">— καμία —</option>
              {thesiOptions.map(o => <option key={o.aa || o.id} value={o.aa || o.id}>{o.name}</option>)}
            </select>
          </div>
        </div>
        <div className="form-grid-3">
          <div className="form-group">
            <label>ΓΑΚ (Γενικός Αριθμός Κατάθεσης)</label>
            <input type="text" value={gak} onChange={e => setGak(e.target.value)} placeholder="π.χ. 12345/2026" />
          </div>
          <div className="form-group">
            <label>ΕΑΚ (Ειδικός Αριθμός Κατάθεσης)</label>
            <input type="text" value={eak} onChange={e => setEak(e.target.value)} placeholder="π.χ. 6789/2026" />
          </div>
          <div className="form-group">
            <label>Αριθμός εισαγωγικού εγγράφου / Κωδικός</label>
            <input type="text" value={arithmosEisagogikou} onChange={e => setArithmosEisagogikou(e.target.value)} />
          </div>
        </div>
        <div className="form-group">
          <label>Περίληψη / Περιγραφή</label>
          <textarea rows="6" value={perilipsi} onChange={e => setPerilipsi(e.target.value)} />
        </div>

        {loadErr && <div className="error">Σφάλμα φόρτωσης προσώπων: {loadErr}</div>}

        {/* --- Πελάτης ΦΠ + ΝΠ + Αντίδικος/Συμβαλλόμενος --- */}
        <div className="form-grid-2" style={{ marginTop: 20, borderTop: '1px solid #e2e8f0', paddingTop: 20 }}>
          <div className="form-group">
            <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
              <label>Πελάτης ΦΠ (Φυσικό Πρόσωπο)</label>
              <a href="#" onClick={e => { e.preventDefault(); setQuickCreate('fysiko'); }} style={{ fontSize: 12 }}>+ Νέος</a>
            </div>
            <select
              value={fysikoProsopoId}
              onChange={e => { setFysikoProsopoId(e.target.value); if (e.target.value) setNomikoProsopoId(''); }}
            >
              <option value="">— κανένας —</option>
              {fysikaList.map(f => (
                <option key={f.aa || f.id} value={f.aa || f.id}>
                  {`${f.eponymo || ''} ${f.onoma || ''}`.trim() || `#${f.aa || f.id}`}
                </option>
              ))}
            </select>
          </div>
          <div className="form-group">
            <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
              <label>Πελάτης ΝΠ (Νομικό Πρόσωπο)</label>
              <a href="#" onClick={e => { e.preventDefault(); setQuickCreate('nomiko'); }} style={{ fontSize: 12 }}>+ Νέο</a>
            </div>
            <select
              value={nomikoProsopoId}
              onChange={e => { setNomikoProsopoId(e.target.value); if (e.target.value) setFysikoProsopoId(''); }}
            >
              <option value="">— κανένα —</option>
              {nomikaList.map(n => (
                <option key={n.aa || n.id} value={n.aa || n.id}>
                  {n.eponymia || n.diakritikos_titlos || `#${n.aa || n.id}`}
                </option>
              ))}
            </select>
          </div>
        </div>
        <div className="form-grid-2">
          <div className="form-group">
            <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
              <label>Αντίδικος / Συμβαλλόμενος</label>
              <a href="#" onClick={e => { e.preventDefault(); setQuickCreate('opponent'); }} style={{ fontSize: 12 }}>+ Νέος</a>
            </div>
            <select value={diadikosId} onChange={e => setDiadikosId(e.target.value)}>
              <option value="">-- κανένας --</option>
              {opponents.map(r => <option key={r.aa || r.id} value={r.aa || r.id}>{`${r.eponymo || ''} ${r.onoma || ''}`.trim()}</option>)}
            </select>
          </div>
          <div />
        </div>

        {/* --- Χειριστές δικηγόροι --- */}
        <div className="form-group" style={{ marginTop: 12 }}>
          <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
            <label>Χειριστές δικηγόροι γραφείου ({xeiristesIds.length} επιλεγμένοι)</label>
            <a href="#" onClick={e => { e.preventDefault(); setQuickCreate('lawyer'); }} style={{ fontSize: 12 }}>+ Νέος δικηγόρος γραφείου</a>
          </div>
          <div style={{ maxHeight: 200, overflow: 'hidden auto', border: '1px solid #e2e8f0', borderRadius: 6, padding: 8 }}>
            {lawyers.length === 0 ? (
              <div style={{ color: '#a0aec0', padding: 8 }}>Δεν υπάρχουν δικηγόροι γραφείου. Πάτησε «+ Νέος δικηγόρος γραφείου» για να προσθέσεις τον πρώτο.</div>
            ) : (() => {
              const hasSelected = xeiristesIds.length > 0;
              return [...lawyers].sort((a, b) => {
                const aId = a.aa || a.id;
                const bId = b.aa || b.id;
                if (hasSelected) {
                  // Υπάρχουν επιλογές: checked πρώτα, μετά αλφαβητικά όλοι οι υπόλοιποι
                  const aChecked = xeiristesIds.includes(aId);
                  const bChecked = xeiristesIds.includes(bId);
                  if (aChecked !== bChecked) return aChecked ? -1 : 1;
                } else {
                  // Δεν υπάρχουν επιλογές: Μαύροι πρώτα, μετά αλφαβητικά όλοι οι υπόλοιποι
                  const aMavros = /^μα[υύ]ρ/i.test((a.eponymo || '').trim());
                  const bMavros = /^μα[υύ]ρ/i.test((b.eponymo || '').trim());
                  if (aMavros !== bMavros) return aMavros ? -1 : 1;
                }
                // Αλφαβητικά μέσα στο group
                const aName = `${a.eponymo || ''} ${a.onoma || ''}`.trim();
                const bName = `${b.eponymo || ''} ${b.onoma || ''}`.trim();
                return aName.localeCompare(bName, 'el');
              }).map((l, idx, arr) => {
                const id = l.aa || l.id;
                const checked = xeiristesIds.includes(id);
                const isLast = idx === arr.length - 1;
                return (
                  <label
                    key={id}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      gap: 12,
                      padding: '8px 10px',
                      cursor: 'pointer',
                      borderRadius: 4,
                      borderBottom: isLast ? 'none' : '1px solid #f1f5f9',
                      transition: 'background 0.1s',
                      boxSizing: 'border-box',
                    }}
                    onMouseEnter={e => e.currentTarget.style.background = '#f8fafc'}
                    onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                  >
                    <span style={{
                      flex: '1 1 auto',
                      minWidth: 0,
                      textAlign: 'left',
                      whiteSpace: 'nowrap',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                    }}>
                      {`${l.eponymo || ''} ${l.onoma || ''}`.trim() || `#${id}`}
                    </span>
                    <input
                      type="checkbox"
                      checked={checked}
                      onChange={() => toggleXeiristis(id)}
                      style={{
                        width: 16,
                        height: 16,
                        flexShrink: 0,
                        margin: 0,
                        padding: 0,
                        border: '1px solid #cbd5e0',
                        borderRadius: 3,
                        cursor: 'pointer',
                      }}
                    />
                  </label>
                );
              });
            })()}
          </div>
          <small style={{ color: '#a0aec0' }}>Ο δικηγόρος αντιδίκου, ο δικαστής και ο γραμματέας ορίζονται ξεχωριστά σε κάθε δικαστική ενέργεια.</small>
        </div>

        <div style={{ textAlign: 'right', marginTop: 20 }}>
          <button type="button" className="btn" disabled={saving} onClick={saveAll}>
            {saving ? 'Αποθήκευση...' : 'Αποθήκευση'}
          </button>
        </div>
      </div>

      <aside className="case-tab-sidebar" style={{ position: 'sticky', top: 20 }}>
        <div className="section" style={{ marginBottom: 16 }}>
          <h3 style={{ fontSize: 14, marginTop: 0, marginBottom: 8 }}>Υποθέσεις ίδιου πελάτη ({sameClientCases.length})</h3>
          {sameClientCases.length === 0 ? (
            <div style={{ color: '#a0aec0', fontSize: 12 }}>Δεν υπάρχουν άλλες υποθέσεις.</div>
          ) : (
            <div style={{ maxHeight: 200, overflowY: 'auto' }}>
              {sameClientCases.map(sc => (
                <a
                  key={sc.aa || sc.id}
                  href={`/cases/${sc.aa || sc.id}`}
                  style={{ display: 'block', padding: '6px 8px', borderBottom: '1px solid #f0f0f0', fontSize: 12, textDecoration: 'none', color: '#2d3748' }}
                >
                  <strong>{sc.xeirokinito_id || `#${sc.aa || sc.id}`}</strong>
                  {sc.perilipsi && <div style={{ color: '#718096', fontSize: 11, marginTop: 2 }}>{sc.perilipsi.substring(0, 60)}{sc.perilipsi.length > 60 ? '...' : ''}</div>}
                </a>
              ))}
            </div>
          )}
        </div>
        <RelatedCasesPanel caseId={caseData.aa || caseData.id} />
      </aside>

      {quickCreate && (
        <QuickCreatePersonModal
          kind={quickCreate}
          onClose={() => setQuickCreate(null)}
          onCreated={(rec) => handleQuickCreated(quickCreate, rec)}
        />
      )}
    </div>
  );
}


// ---------- Tab 2: Court Actions ----------
function CourtActionsTab({ caseId, rows, courts, onChange }) {
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState(null);
  const [confirmDel, setConfirmDel] = useState(null);

  const openNew = () => { setEditing(null); setShowModal(true); };
  const openEdit = (r) => { setEditing(r); setShowModal(true); };

  const doDelete = async (r) => {
    try { await actions.court.remove(r.aa || r.id); onChange(); } catch (e) { alert(e.message); }
  };

  return (
    <div>
      <div className="section-header" style={{ padding: 0, marginBottom: 16 }}>
        <div style={{ color: '#4a5568' }}>Δικαστικές ενέργειες (δικάσιμοι)</div>
        <button type="button" className="btn btn-sm" onClick={openNew}>+ Νέα δικαστική ενέργεια</button>
      </div>

      {rows.length === 0 ? (
        <div className="empty-state">Δεν υπάρχουν δικαστικές ενέργειες.</div>
      ) : (
        <table className="table">
          <thead><tr>
            <th style={{width:110}}>Ημ/νία δικασίμου</th>
            <th style={{width:110}}>Ημ. Απόφασης</th>
            <th>Τίτλος</th>
            <th>Δικαστήριο</th>
            <th>Διαδικασία</th>
            <th style={{width:90}}>Κατάσταση</th>
            <th style={{width:1}}></th>
          </tr></thead>
          <tbody>
            {rows.map(r => (
              <tr key={r.aa || r.id}>
                <td>{fmtDate(r.date)}</td>
                <td>{r.date_apofasis ? fmtDate(r.date_apofasis) : '—'}</td>
                <td>{r.name || '—'}</td>
                <td>{r.dikastirio_name || courts.find(c => (c.aa||c.id) === r.dikastirio_id)?.name || '—'}</td>
                <td>{r.diadikasia_name || '—'}</td>
                <td>
                  <span className={`badge ${r.ekkremis !== false ? 'badge-open' : 'badge-closed'}`}>
                    {r.ekkremis !== false ? 'Εκκρεμής' : 'Έκλεισε'}
                  </span>
                </td>
                <td style={{ whiteSpace: 'nowrap' }}>
                  <CalendarExportButton event={eventFromCourtAction(r)} filename={`dikasimos-${r.aa}.ics`} />
                  {' '}
                  <button className="btn btn-sm btn-secondary" onClick={() => openEdit(r)}>Επεξ.</button>
                  {' '}
                  <button className="btn btn-sm btn-danger" onClick={() => setConfirmDel(r)}>×</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {showModal && (
        <CourtActionModal
          caseId={caseId}
          courts={courts}
          initial={editing}
          onClose={() => setShowModal(false)}
          onSaved={() => { setShowModal(false); onChange(); }}
        />
      )}
      {confirmDel && (
        <ConfirmDialog
          title="Διαγραφή Δικαστικής Ενέργειας"
          message="Είστε σίγουρος;"
          confirmLabel="Διαγραφή"
          onConfirm={() => doDelete(confirmDel)}
          onClose={() => setConfirmDel(null)}
        />
      )}
    </div>
  );
}

function CourtActionModal({ caseId, courts, initial, onClose, onSaved }) {
  const [form, setForm] = useState({
    name:                   initial?.name || '',
    date:                   toDateInput(initial?.date) || '',
    date_apofasis:          toDateInput(initial?.date_apofasis) || '',
    ekkremis:               initial?.ekkremis !== false,
    dikastirio_id:          initial?.dikastirio_id || '',
    diadikasia_id:          initial?.diadikasia_id || '',
    antidikos_id:           initial?.antidikos_id || '',
    dikigoros_antidikou_id: initial?.dikigoros_antidikou_id || '',
    pinakio:                initial?.pinakio || '',
  });
  const [procedures, setProcedures] = useState([]);
  const [opponents, setOpponents] = useState([]);
  const [opposingLawyers, setOpposingLawyers] = useState([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [quickCreate, setQuickCreate] = useState(null); // 'opponent' | 'opposing-lawyer'

  const reloadPeople = () => {
    people.opponents.list()
      .then(d => setOpponents(Array.isArray(d) ? d : (d?.data || [])))
      .catch(() => {});
    people.opposingLawyers.list()
      .then(d => setOpposingLawyers(Array.isArray(d) ? d : (d?.data || [])))
      .catch(() => {});
  };

  useEffect(() => {
    lists.get('diadikasies')
      .then(d => setProcedures(Array.isArray(d) ? d : (d?.data || [])))
      .catch(() => {});
    reloadPeople();
  }, []);

  const c = (k) => (e) => setForm(f => ({ ...f, [k]: e.target.value }));

  const handleQuickCreated = (kind, rec) => {
    setQuickCreate(null);
    reloadPeople();
    const newId = rec?.aa || rec?.id;
    if (!newId) return;
    if (kind === 'opponent') setForm(f => ({ ...f, antidikos_id: newId }));
    else if (kind === 'opposing-lawyer') setForm(f => ({ ...f, dikigoros_antidikou_id: newId }));
  };

  const save = async () => {
    setSaving(true);
    setError('');
    if (!form.date) { setError('Η ημερομηνία είναι υποχρεωτική.'); setSaving(false); return; }
    try {
      const payload = {
        ypothesi_id:            Number(caseId),
        name:                   form.name || null,
        date:                   form.date,
        date_apofasis:          form.date_apofasis || null,
        ekkremis:               !!form.ekkremis,
        dikastirio_id:          form.dikastirio_id ? Number(form.dikastirio_id) : null,
        diadikasia_id:          form.diadikasia_id ? Number(form.diadikasia_id) : null,
        antidikos_id:           form.antidikos_id ? Number(form.antidikos_id) : null,
        dikigoros_antidikou_id: form.dikigoros_antidikou_id ? Number(form.dikigoros_antidikou_id) : null,
        pinakio:                form.pinakio || null,
      };
      if (initial?.aa || initial?.id) await actions.court.update(initial.aa || initial.id, payload);
      else await actions.court.create(payload);
      onSaved();
    } catch (e) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal
      title={initial ? 'Επεξεργασία δικαστικής ενέργειας' : 'Νέα δικαστική ενέργεια'}
      onClose={onClose}
      size="lg"
      actions={<>
        <button type="button" className="btn btn-secondary" onClick={onClose}>Ακύρωση</button>
        <button type="button" className="btn" disabled={saving} onClick={save}>{saving ? 'Αποθήκευση...' : 'Αποθήκευση'}</button>
      </>}
    >
      {error && <div className="error">{error}</div>}
      <div className="form-grid-2">
        <div className="form-group">
          <label>Ημερομηνία δικασίμου *</label>
          <input type="date" value={form.date} onChange={c('date')} />
        </div>
        <div className="form-group">
          <label>Τίτλος / Ονομασία</label>
          <input type="text" value={form.name} onChange={c('name')} />
        </div>
      </div>
      <div className="form-grid-2">
        <div className="form-group">
          <label>Δικαστήριο</label>
          <select value={form.dikastirio_id} onChange={c('dikastirio_id')}>
            <option value="">-- επιλογή --</option>
            {courts.map(co => <option key={co.aa || co.id} value={co.aa || co.id}>{co.name || co.onomasia}</option>)}
          </select>
        </div>
        <div className="form-group">
          <label>Διαδικασία</label>
          <select value={form.diadikasia_id} onChange={c('diadikasia_id')}>
            <option value="">-- επιλογή --</option>
            {procedures.map(p => <option key={p.aa || p.id} value={p.aa || p.id}>{p.name || p.onomasia}</option>)}
          </select>
        </div>
      </div>
      <div className="form-grid-2">
        <div className="form-group">
          <label style={{ display: 'flex', justifyContent: 'space-between' }}>
            <span>Αντίδικος / Συμβαλλόμενος</span>
            <a href="#" onClick={e => { e.preventDefault(); setQuickCreate('opponent'); }} style={{ fontSize: 12, fontWeight: 'normal' }}>+ Νέος</a>
          </label>
          <select value={form.antidikos_id} onChange={c('antidikos_id')}>
            <option value="">-- κανένας --</option>
            {opponents.map(o => <option key={o.aa || o.id} value={o.aa || o.id}>{`${o.eponymo || ''} ${o.onoma || ''}`.trim()}</option>)}
          </select>
        </div>
        <div className="form-group">
          <label style={{ display: 'flex', justifyContent: 'space-between' }}>
            <span>Δικηγόρος αντιδίκου</span>
            <a href="#" onClick={e => { e.preventDefault(); setQuickCreate('opposing-lawyer'); }} style={{ fontSize: 12, fontWeight: 'normal' }}>+ Νέος</a>
          </label>
          <select value={form.dikigoros_antidikou_id} onChange={c('dikigoros_antidikou_id')}>
            <option value="">-- κανένας --</option>
            {opposingLawyers.map(o => <option key={o.aa || o.id} value={o.aa || o.id}>{`${o.eponymo || ''} ${o.onoma || ''}`.trim()}</option>)}
          </select>
        </div>
      </div>
      <div className="form-group">
        <label>Πινάκιο</label>
        <input type="text" value={form.pinakio} onChange={c('pinakio')} />
      </div>

      <div className="form-grid-2">
        <div className="form-group">
          <label>Ημ. Έκδοσης Απόφασης</label>
          <input type="date" value={form.date_apofasis} onChange={c('date_apofasis')} />
        </div>
        <div className="form-group">
          <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', marginTop: 24 }}>
            <input type="checkbox" checked={form.ekkremis} onChange={e => setForm(f => ({ ...f, ekkremis: e.target.checked }))} />
            <span>Εκκρεμής</span>
          </label>
        </div>
      </div>

      {initial?.aa && (
        <CourtSubActionsSection courtAction={initial} />
      )}

      {quickCreate && (
        <QuickCreatePersonModal
          kind={quickCreate}
          onClose={() => setQuickCreate(null)}
          onCreated={(rec) => handleQuickCreated(quickCreate, rec)}
        />
      )}
    </Modal>
  );
}

// ---------- Court Sub-Actions Section ----------
function CourtSubActionsSection({ courtAction }) {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [lawyers, setLawyers] = useState([]);
  const [energeiaOptions, setEnergeiaOptions] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [confirmDel, setConfirmDel] = useState(null);

  const load = () => {
    setLoading(true);
    courtSubActions.listByCourtAction(courtAction.aa)
      .then(d => setRows(Array.isArray(d) ? d : (d?.data || [])))
      .catch(e => setError(e.message))
      .finally(() => setLoading(false));
  };
  useEffect(() => {
    load();
    Promise.allSettled([
      people.lawyers.list(),
      lists.get('dikastiria_exelixi_energeias'),
    ]).then(([lRes, eRes]) => {
      const unwrap = v => Array.isArray(v) ? v : (v?.data || []);
      if (lRes.status === 'fulfilled') setLawyers(unwrap(lRes.value));
      if (eRes.status === 'fulfilled') setEnergeiaOptions(unwrap(eRes.value));
    });
    // eslint-disable-next-line
  }, [courtAction.aa]);

  const doDelete = async (r) => {
    try { await courtSubActions.remove(r.aa); load(); setConfirmDel(null); }
    catch (e) { setError(e.message); }
  };

  return (
    <div style={{ marginTop: 20, borderTop: '1px solid #e2e8f0', paddingTop: 16 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 10 }}>
        <h3 style={{ margin: 0, fontSize: 14 }}>Ενέργειες αυτής της δικασίμου ({rows.length})</h3>
        <button type="button" className="btn btn-sm" onClick={() => { setEditing(null); setShowForm(true); }}>+ Νέα ενέργεια</button>
      </div>
      {error && <div className="error">{error}</div>}
      {loading ? (
        <div style={{ color: '#a0aec0', fontSize: 13 }}>Φόρτωση...</div>
      ) : rows.length === 0 ? (
        <div style={{ color: '#a0aec0', fontSize: 13, padding: 10, textAlign: 'center', background: '#f7fafc', borderRadius: 4 }}>
          Δεν έχουν καταχωρηθεί ενέργειες για αυτή τη δικάσιμο.
        </div>
      ) : (
        <table className="table" style={{ fontSize: 12 }}>
          <thead><tr>
            <th style={{width:95}}>Ημ/νία</th>
            <th>Ενέργεια</th>
            <th style={{width:95}}>Ημ. Απόφασης</th>
            <th style={{width:130}}>Χειριστής</th>
            <th style={{width:80}}>Κατάσταση</th>
            <th style={{width:1}}></th>
          </tr></thead>
          <tbody>
            {rows.map(r => (
              <tr key={r.aa}>
                <td>{fmtDate(r.date)}</td>
                <td>
                  <div>{r.energeia_name || r.perigrafi || '—'}</div>
                  {r.energeia_name && r.perigrafi && <div style={{ color: '#a0aec0', fontSize: 11 }}>{r.perigrafi}</div>}
                </td>
                <td>{r.date_apofasis ? fmtDate(r.date_apofasis) : '—'}</td>
                <td>{r.dikigoros_name || '—'}</td>
                <td>
                  <span className={`badge ${r.ekkremis !== false ? 'badge-open' : 'badge-closed'}`}>
                    {r.ekkremis !== false ? 'Εκκρεμής' : 'Έκλεισε'}
                  </span>
                </td>
                <td style={{ whiteSpace: 'nowrap' }}>
                  <CalendarExportButton event={eventFromCourtSubAction(r, courtAction)} filename={`energeia-${r.aa}.ics`} />
                  {' '}
                  <button type="button" className="btn btn-sm btn-secondary" onClick={() => { setEditing(r); setShowForm(true); }}>✎</button>
                  {' '}
                  <button type="button" className="btn btn-sm btn-danger" onClick={() => setConfirmDel(r)}>×</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {showForm && (
        <SubActionModal
          courtActionId={courtAction.aa}
          initial={editing}
          lawyers={lawyers}
          energeiaOptions={energeiaOptions}
          onClose={() => setShowForm(false)}
          onSaved={() => { setShowForm(false); load(); }}
        />
      )}
      {confirmDel && (
        <ConfirmDialog
          title="Διαγραφή ενέργειας"
          message="Η ενέργεια θα διαγραφεί οριστικά."
          confirmLabel="Διαγραφή"
          onConfirm={() => doDelete(confirmDel)}
          onClose={() => setConfirmDel(null)}
        />
      )}
    </div>
  );
}

function SubActionModal({ courtActionId, initial, lawyers, energeiaOptions, onClose, onSaved }) {
  const [form, setForm] = useState({
    energeia_lookup_id: initial?.energeia_lookup_id || '',
    perigrafi:          initial?.perigrafi || '',
    date:               toDateInput(initial?.date) || '',
    dikigoros_id:       initial?.dikigoros_id || '',
    date_apofasis:      toDateInput(initial?.date_apofasis) || '',
    ekkremis:           initial?.ekkremis !== false,
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const c = (k) => (e) => {
    const v = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
    setForm(f => ({ ...f, [k]: v }));
  };

  const onEnergeiaSelect = (e) => {
    const id = e.target.value;
    const sel = energeiaOptions.find(o => String(o.aa || o.id) === id);
    setForm(f => ({
      ...f,
      energeia_lookup_id: id,
      // Auto-fill description if empty
      perigrafi: (!f.perigrafi || f.perigrafi === '') && sel ? (sel.name || sel.perigrafi || '') : f.perigrafi,
    }));
  };

  const save = async () => {
    setError('');
    setSaving(true);
    try {
      const payload = {
        court_action_id:    courtActionId,
        energeia_lookup_id: form.energeia_lookup_id ? Number(form.energeia_lookup_id) : null,
        perigrafi:          form.perigrafi || null,
        date:               form.date || null,
        dikigoros_id:       form.dikigoros_id ? Number(form.dikigoros_id) : null,
        date_apofasis:      form.date_apofasis || null,
        ekkremis:           !!form.ekkremis,
      };
      if (initial?.aa) await courtSubActions.update(initial.aa, payload);
      else await courtSubActions.create(payload);
      onSaved();
    } catch (e) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal
      title={initial ? 'Επεξεργασία ενέργειας' : 'Νέα ενέργεια δικασίμου'}
      onClose={onClose}
      actions={<>
        <button type="button" className="btn btn-secondary" onClick={onClose}>Ακύρωση</button>
        <button type="button" className="btn" disabled={saving} onClick={save}>{saving ? 'Αποθήκευση...' : 'Αποθήκευση'}</button>
      </>}
    >
      {error && <div className="error">{error}</div>}
      <div className="form-group">
        <label>Είδος ενέργειας</label>
        <select value={form.energeia_lookup_id} onChange={onEnergeiaSelect}>
          <option value="">— επιλογή από λίστα —</option>
          {energeiaOptions.map(o => (
            <option key={o.aa || o.id} value={o.aa || o.id}>{o.name || o.perigrafi}</option>
          ))}
        </select>
        <small style={{ color: '#a0aec0' }}>Η περιγραφή θα γεμίσει αυτόματα από την επιλογή.</small>
      </div>
      <div className="form-group">
        <label>Περιγραφή</label>
        <textarea rows="3" value={form.perigrafi} onChange={c('perigrafi')} />
      </div>
      <div className="form-grid-2">
        <div className="form-group">
          <label>Ημερομηνία</label>
          <input type="date" value={form.date} onChange={c('date')} />
        </div>
        <div className="form-group">
          <label>Χειριστής δικηγόρος</label>
          <select value={form.dikigoros_id} onChange={c('dikigoros_id')}>
            <option value="">— κανένας —</option>
            {lawyers.map(l => (
              <option key={l.aa || l.id} value={l.aa || l.id}>
                {`${l.eponymo || ''} ${l.onoma || ''}`.trim()}
              </option>
            ))}
          </select>
        </div>
      </div>
      <div className="form-grid-2">
        <div className="form-group">
          <label>Ημ. Έκδοσης Απόφασης</label>
          <input type="date" value={form.date_apofasis} onChange={c('date_apofasis')} />
        </div>
        <div className="form-group">
          <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', marginTop: 24 }}>
            <input type="checkbox" checked={form.ekkremis} onChange={c('ekkremis')} />
            <span>Εκκρεμής</span>
          </label>
          <small style={{ color: '#a0aec0' }}>Αυτόματα κλείνει όταν παρέλθει η ημερομηνία.</small>
        </div>
      </div>
    </Modal>
  );
}

// ---------- Tab: Documents ----------
function DocsTab({ caseId, rows, onChange }) {
  const [uploading, setUploading] = useState(false);
  const [preview, setPreview] = useState(null);
  const [confirmDel, setConfirmDel] = useState(null);
  const [error, setError] = useState('');
  const [selected, setSelected] = useState(null);
  const [newFilePrompt, setNewFilePrompt] = useState(null); // 'docx' | 'xlsx'
  const [newFileName, setNewFileName] = useState('');
  const [showTemplatePicker, setShowTemplatePicker] = useState(false);

  const onUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    setError('');
    try {
      // Extract metadata (author, last modified by, etc.) client-side before upload
      const metadata = await extractFileMetadata(file);
      await documents.upload(caseId, file, '', metadata);
      onChange();
    } catch (err) {
      setError(err.message);
    } finally {
      setUploading(false);
      e.target.value = '';
    }
  };

  const createNewOfficeFile = async () => {
    if (!newFileName.trim()) { setError('Δώσε όνομα για το νέο αρχείο.'); return; }
    setError('');
    setUploading(true);
    try {
      const isDocx = newFilePrompt === 'docx';
      const blob = isDocx ? createEmptyDocx() : createEmptyXlsx();
      const ext = isDocx ? '.docx' : '.xlsx';
      const name = newFileName.trim().endsWith(ext) ? newFileName.trim() : newFileName.trim() + ext;
      const file = blobToFile(blob, name);
      const metadata = await extractFileMetadata(file);
      await documents.upload(caseId, file, '', metadata);
      setNewFilePrompt(null);
      setNewFileName('');
      onChange();
    } catch (err) {
      setError(err.message);
    } finally {
      setUploading(false);
    }
  };

  const openPreview = async (doc) => {
    try {
      const res = await documents.downloadUrl(doc.aa || doc.id);
      const url = res?.url || res?.download_url || res?.data?.url || res?.signed_url || res?.signedUrl;
      if (!url) { setError('Δεν βρέθηκε URL αρχείου.'); return; }
      const name = doc.file_name || doc.fileName || doc.filename || doc.name || doc.original_name || doc.originalName || 'αρχείο';
      const ext = (name.split('.').pop() || '').toLowerCase();
      setPreview({ url, name, ext });
    } catch (e) {
      setError(e.message);
    }
  };

  const doDelete = async (doc) => {
    try { await documents.remove(doc.aa || doc.id); onChange(); }
    catch (e) { setError(e.message); }
  };

  const docName = (d) => d.filename || d.file_name || d.fileName || d.name || d.original_name || d.originalName || '—';
  const docSize = (d) => d.size_bytes ?? d.file_size ?? d.fileSize ?? d.size ?? d.bytes ?? null;
  const docDate = (d) => d.uploaded_at || d.uploadedAt || d.created_at || d.createdAt || d.date || null;
  const docUser = (d) => {
    // 1st: file's own metadata (Word "Last saved by", PDF "Author") — if backend stores it
    const meta = d.metadata_last_modified_by || d.metadataLastModifiedBy || d.metadata_author || d.metadataAuthor;
    if (meta) return meta;
    // 2nd: backend's JOIN on users: uploader_first + uploader_last
    if (d.uploader_first || d.uploader_last) return [d.uploader_first, d.uploader_last].filter(Boolean).join(' ');
    return '—';
  };
  const fileIcon = (name) => {
    const ext = (name.split('.').pop() || '').toLowerCase();
    if (['doc','docx','docm','odt','rtf'].includes(ext)) return '📄';
    if (['xls','xlsx','xlsm','csv','ods'].includes(ext)) return '📊';
    if (ext === 'pdf') return '📕';
    if (['ppt','pptx','pptm','odp'].includes(ext)) return '📽️';
    if (['jpg','jpeg','png','gif','webp','svg','bmp','tiff'].includes(ext)) return '🖼️';
    if (['zip','rar','7z','tar','gz'].includes(ext)) return '🗜️';
    if (['mp4','mov','avi','mkv','webm'].includes(ext)) return '🎥';
    if (['mp3','wav','ogg','flac','m4a'].includes(ext)) return '🎵';
    if (['txt','md','log'].includes(ext)) return '📃';
    return '📎';
  };

  const openDownload = async (doc) => {
    setError('');
    try {
      const res = await documents.downloadUrl(doc.aa || doc.id);
      const url = res?.url || res?.download_url || res?.data?.url || res?.signed_url || res?.signedUrl;
      if (!url) { setError('Δεν βρέθηκε URL αρχείου.'); return; }
      // Open in new tab — browser will download or preview depending on content-disposition
      window.open(url, '_blank', 'noopener');
    } catch (e) {
      setError(e.message);
    }
  };

  return (
    <div>
      {error && <div className="error">{error}</div>}
      <div className="section-header" style={{ padding: 0, marginBottom: 16, gap: 8, flexWrap: 'wrap' }}>
        <div style={{ color: '#4a5568' }}>Αρχεία υπόθεσης</div>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          <button type="button" className="btn btn-sm btn-secondary" onClick={() => setShowTemplatePicker(true)}>📋 Από υπόδειγμα</button>
          <button type="button" className="btn btn-sm btn-secondary" onClick={() => { setNewFilePrompt('docx'); setNewFileName(''); }}>📄 Νέο Word</button>
          <button type="button" className="btn btn-sm btn-secondary" onClick={() => { setNewFilePrompt('xlsx'); setNewFileName(''); }}>📊 Νέο Excel</button>
          <label className={`btn btn-sm ${uploading ? 'btn-disabled' : ''}`} style={{ margin: 0, cursor: 'pointer' }}>
            {uploading ? 'Ανέβασμα...' : '📎 Ανέβασμα αρχείου'}
            <input type="file" style={{ display: 'none' }} onChange={onUpload} disabled={uploading} />
          </label>
        </div>
      </div>

      <div style={{ display: 'flex', gap: 16, alignItems: 'flex-start' }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          {rows.length === 0 ? (
            <div className="empty-state">Δεν υπάρχουν αρχεία σε αυτή την υπόθεση.</div>
          ) : (
            <table className="table">
              <thead><tr>
                <th>Όνομα</th>
                <th style={{width:110}}>Μέγεθος</th>
                <th style={{width:160}}>Ανέβηκε</th>
                <th style={{width:180}}>Επεξεργάστηκε από</th>
                <th style={{width:1}}></th>
              </tr></thead>
              <tbody>
                {rows.map(d => {
                  const name = docName(d);
                  const size = docSize(d);
                  const isSelected = selected && (selected.aa || selected.id) === (d.aa || d.id);
                  // Το αρχείο δεν βρέθηκε στον αποθηκευτικό χώρο —
                  // δείχνουμε ένδειξη αντί να αφήσουμε τον χρήστη να πάρει σφάλμα.
                  const missing = !!d.file_missing;
                  return (
                    <tr
                      key={d.aa || d.id}
                      className={`clickable ${isSelected ? 'row-selected' : ''}`}
                      onClick={() => setSelected(d)}
                      style={missing ? { opacity: 0.65 } : undefined}
                    >
                      <td>
                        <span style={{ marginRight: 6 }}>{missing ? '⚠️' : fileIcon(name)}</span>
                        <span style={missing ? { textDecoration: 'line-through', color: '#94A3B8' } : undefined}>
                          {name}
                        </span>
                        {missing && (
                          <span
                            title="Η εγγραφή υπάρχει, αλλά το αρχείο δεν βρέθηκε στον αποθηκευτικό χώρο. Πιθανόν δεν μεταφέρθηκε από το παλιό σύστημα."
                            style={{
                              marginLeft: 8, fontSize: 11, padding: '2px 8px', borderRadius: 10,
                              background: '#FEF3C7', color: '#92400E', whiteSpace: 'nowrap',
                            }}
                          >μη διαθέσιμο</span>
                        )}
                      </td>
                      <td>{size != null ? formatBytes(size) : '—'}</td>
                      <td>{docDate(d) ? fmtDateTime(docDate(d)) : '—'}</td>
                      <td>{docUser(d)}</td>
                      <td style={{ whiteSpace: 'nowrap' }}>
                        {missing ? (
                          <span style={{ fontSize: 12, color: '#94A3B8' }}>—</span>
                        ) : (
                          <>
                            <button className="btn btn-sm" onClick={(e) => { e.stopPropagation(); openDownload(d); }}>⬇ Λήψη</button>
                            {' '}
                            <button className="btn btn-sm btn-secondary" onClick={(e) => { e.stopPropagation(); openPreview(d); }}>Προβολή</button>
                            {' '}
                          </>
                        )}
                        <button className="btn btn-sm btn-danger" onClick={(e) => { e.stopPropagation(); setConfirmDel(d); }}>×</button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>

        {selected && (
          <div style={{ width: 280, flexShrink: 0, background: '#f7fafc', borderRadius: 8, padding: 16 }}>
            <h3 style={{ fontSize: 13, color: '#718096', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 12 }}>Λεπτομέρειες αρχείου</h3>
            <div style={{ fontSize: 13, lineHeight: 1.7 }}>
              <div><strong>{docName(selected)}</strong></div>
              <div style={{ color: '#718096', marginTop: 8 }}>
                <div><strong>Μέγεθος:</strong> {docSize(selected) != null ? formatBytes(docSize(selected)) : '—'}</div>
                <div><strong>Ανέβηκε:</strong> {docDate(selected) ? fmtDateTime(docDate(selected)) : '—'}</div>
                <div><strong>Ανέβηκε από:</strong> {docUser(selected)}</div>
                {(selected.metadata_author || selected.metadata_created_at) && (
                  <>
                    <hr style={{ margin: '10px 0', border: 'none', borderTop: '1px solid #cbd5e0' }} />
                    <div style={{ fontWeight: 600, color: '#4a5568', marginBottom: 6 }}>Ιδιότητες εγγράφου</div>
                    {selected.metadata_author && <div><strong>Συγγραφέας:</strong> {selected.metadata_author}</div>}
                    {selected.metadata_last_modified_by && selected.metadata_last_modified_by !== selected.metadata_author && (
                      <div><strong>Τελ. επιμελητής:</strong> {selected.metadata_last_modified_by}</div>
                    )}
                    {selected.metadata_created_at && <div><strong>Ημ. δημιουργίας:</strong> {fmtDateTime(selected.metadata_created_at)}</div>}
                    {selected.metadata_modified_at && <div><strong>Ημ. αποθήκευσης:</strong> {fmtDateTime(selected.metadata_modified_at)}</div>}
                    {selected.metadata_title && <div><strong>Τίτλος:</strong> {selected.metadata_title}</div>}
                  </>
                )}
              </div>
              <button className="btn btn-sm btn-secondary" style={{ marginTop: 12, width: '100%' }} onClick={() => setSelected(null)}>Κλείσιμο</button>
            </div>
          </div>
        )}
      </div>

      {newFilePrompt && (
        <Modal
          title={newFilePrompt === 'docx' ? 'Νέο Word έγγραφο' : 'Νέο Excel αρχείο'}
          onClose={() => setNewFilePrompt(null)}
          actions={<>
            <button type="button" className="btn btn-secondary" onClick={() => setNewFilePrompt(null)}>Ακύρωση</button>
            <button type="button" className="btn" disabled={uploading || !newFileName.trim()} onClick={createNewOfficeFile}>
              {uploading ? 'Δημιουργία...' : 'Δημιουργία & Ανέβασμα'}
            </button>
          </>}
        >
          <div className="form-group">
            <label>Όνομα αρχείου</label>
            <input
              type="text"
              autoFocus
              value={newFileName}
              onChange={e => setNewFileName(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && newFileName.trim() && createNewOfficeFile()}
              placeholder={newFilePrompt === 'docx' ? 'π.χ. Αγωγή' : 'π.χ. Υπολογισμός κόστους'}
            />
            <small style={{ color: '#a0aec0' }}>Η κατάληξη {newFilePrompt === 'docx' ? '.docx' : '.xlsx'} θα προστεθεί αυτόματα αν λείπει.</small>
          </div>
        </Modal>
      )}

      {preview && (
        <Modal title={preview.name} onClose={() => setPreview(null)} size="xl"
          actions={<>
            <a href={preview.url} target="_blank" rel="noreferrer" className="btn">⬇ Λήψη</a>
            <button type="button" className="btn btn-secondary" onClick={() => setPreview(null)}>Κλείσιμο</button>
          </>}
        >
          <FilePreview url={preview.url} ext={preview.ext} name={preview.name} />
        </Modal>
      )}

      {confirmDel && (
        <ConfirmDialog
          title="Διαγραφή αρχείου"
          message={`Διαγραφή του "${docName(confirmDel)}"; Η ενέργεια δεν αναιρείται.`}
          confirmLabel="Διαγραφή"
          onConfirm={() => doDelete(confirmDel)}
          onClose={() => setConfirmDel(null)}
        />
      )}
      {showTemplatePicker && (
        <TemplatePickerModal
          caseId={caseId}
          onClose={() => setShowTemplatePicker(false)}
          onCreated={() => { setShowTemplatePicker(false); onChange(); }}
        />
      )}
    </div>
  );
}

function TemplatePickerModal({ caseId, onClose, onCreated }) {
  const [templateList, setTemplateList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState('');
  const [selectedId, setSelectedId] = useState('');

  useEffect(() => {
    templates.list()
      .then(d => setTemplateList(Array.isArray(d) ? d : (d?.data || [])))
      .catch(e => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  const doCreate = async () => {
    if (!selectedId) { setError('Επίλεξε ένα υπόδειγμα.'); return; }
    setCreating(true);
    setError('');
    try {
      await templates.createDoc(selectedId, caseId);
      onCreated();
    } catch (e) {
      setError(e.message);
    } finally {
      setCreating(false);
    }
  };

  const grouped = {};
  templateList.forEach(t => {
    const cat = t.category || 'Χωρίς κατηγορία';
    if (!grouped[cat]) grouped[cat] = [];
    grouped[cat].push(t);
  });

  return (
    <Modal
      title="Δημιουργία εγγράφου από υπόδειγμα"
      onClose={onClose}
      size="lg"
      actions={<>
        <button className="btn btn-secondary" onClick={onClose}>Ακύρωση</button>
        <button className="btn" disabled={creating || !selectedId} onClick={doCreate}>
          {creating ? 'Δημιουργία...' : 'Δημιουργία εγγράφου'}
        </button>
      </>}
    >
      {error && <div className="error">{error}</div>}
      <div style={{ color: '#718096', fontSize: 13, marginBottom: 12 }}>
        Επίλεξε ένα υπόδειγμα. Τα placeholders θα γεμίσουν αυτόματα με τα στοιχεία της υπόθεσης και το έγγραφο θα αποθηκευτεί στα Αρχεία της υπόθεσης.
      </div>
      {loading ? (
        <div className="empty-state">Φόρτωση υποδειγμάτων...</div>
      ) : templateList.length === 0 ? (
        <div className="empty-state">
          Δεν υπάρχουν υποδείγματα.
          <br /><small>Ζήτησε από τον διαχειριστή να ανεβάσει από τη σελίδα «Υποδείγματα».</small>
        </div>
      ) : (
        <div style={{ maxHeight: 400, overflowY: 'auto' }}>
          {Object.entries(grouped).map(([category, items]) => (
            <div key={category} style={{ marginBottom: 12 }}>
              <div style={{ fontSize: 11, color: '#718096', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 4 }}>{category}</div>
              {items.map(t => (
                <label
                  key={t.aa}
                  style={{
                    display: 'flex', gap: 8, padding: 8, cursor: 'pointer',
                    borderRadius: 4,
                    background: String(selectedId) === String(t.aa) ? '#ebf8ff' : 'transparent',
                    border: `1px solid ${String(selectedId) === String(t.aa) ? '#667eea' : '#e2e8f0'}`,
                    marginBottom: 4,
                  }}
                >
                  <input
                    type="radio"
                    name="template"
                    value={t.aa}
                    checked={String(selectedId) === String(t.aa)}
                    onChange={() => setSelectedId(t.aa)}
                  />
                  <div style={{ flex: 1 }}>
                    <strong>{t.name}</strong>
                    {t.description && <div style={{ fontSize: 12, color: '#718096' }}>{t.description}</div>}
                  </div>
                </label>
              ))}
            </div>
          ))}
        </div>
      )}
    </Modal>
  );
}

function FilePreview({ url, ext, name }) {
  if (['jpg','jpeg','png','gif','webp','svg'].includes(ext)) {
    return <img src={url} alt={name} style={{ maxWidth: '100%', maxHeight: '70vh', display: 'block', margin: '0 auto' }} />;
  }
  if (ext === 'pdf') {
    return <iframe src={url} title={name} style={{ width: '100%', height: '70vh', border: 'none' }} />;
  }
  return (
    <div style={{ textAlign: 'center', padding: 40 }}>
      <div style={{ fontSize: 48, opacity: 0.4, marginBottom: 12 }}>📄</div>
      <p style={{ color: '#718096', marginBottom: 20 }}>Δεν είναι δυνατή η προεπισκόπηση αυτού του τύπου αρχείου ({ext.toUpperCase()}).</p>
      <a href={url} target="_blank" rel="noreferrer" className="btn">⬇ Λήψη αρχείου</a>
    </div>
  );
}

function formatBytes(b) {
  if (!b) return '—';
  const kb = b / 1024;
  if (kb < 1024) return `${kb.toFixed(1)} KB`;
  return `${(kb / 1024).toFixed(2)} MB`;
}

export default CaseEdit;


